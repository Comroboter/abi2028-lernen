import json,wave,hashlib,os,subprocess,io
from piper import PiperVoice, SynthesisConfig
N=json.load(open('narration.json',encoding='utf-8'))
os.makedirs('audio',exist_ok=True); os.makedirs('.ttscache',exist_ok=True)
v=PiperVoice.load('/tmp/voice/de-kerstin-low.onnx'); sr=v.config.sample_rate
cfg=SynthesisConfig(length_scale=0.93,noise_scale=0.75,noise_w_scale=0.9)
timing={}
for sid,segs in N.items():
    pcm=b''; t=[]; gap=int(sr*0.45)*2
    for sel,txt in segs:
        h=hashlib.md5(txt.encode()).hexdigest(); f=f'.ttscache/k{h}.wav'
        if not os.path.exists(f):
            with wave.open(f,'wb') as w: v.synthesize_wav(txt,w,syn_config=cfg)
        with wave.open(f,'rb') as w: data=w.readframes(w.getnframes())
        start=len(pcm)/2/sr; pcm+=data; end=len(pcm)/2/sr; t.append([round(start,2),round(end,2)]); pcm+=b'\0'*gap
    timing[sid]=t
    raw=f'/tmp/{sid}.raw'; open(raw,'wb').write(pcm)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','s16le','-ar',str(sr),'-ac','1','-i',raw,'-af','highpass=f=70,loudnorm=I=-16:TP=-1.5','-c:a','libmp3lame','-b:a','40k','-ar','22050',f'audio/{sid}.mp3'],check=True)
    print(sid, t[-1][1], 's')
json.dump(timing,open('narr_timing.json','w'),indent=0)
