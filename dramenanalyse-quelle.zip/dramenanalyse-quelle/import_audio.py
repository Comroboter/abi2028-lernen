# Externe Sprachaufnahmen (01-start.mp3 ...) einlesen und Wort-Zeitpunkte schätzen.
# Anker: Sprechpausen, die zu Satzzeichen passen. Dazwischen nach Silbenzahl verteilt.
import json, subprocess, re, sys, os, glob
N = json.load(open('narration.json', encoding='utf-8'))
src = sys.argv[1]
VOW = re.compile(r'[aeiouäöüy]+', re.I)
def syl(w):
    w = re.sub(r'[^A-Za-zÄÖÜäöüß]', '', w)
    return max(1, len(VOW.findall(w))) if w else 0.6

def silences(f, dur):
    log = subprocess.run(['ffmpeg', '-i', f, '-af', 'silencedetect=noise=-36dB:d=0.11', '-f', 'null', '-'], capture_output=True, text=True).stderr
    st = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', log)]
    en = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', log)]
    return [(s, e) for s, e in zip(st, en) if e - s >= 0.11]

out = {}
for k, sid in enumerate(N):
    f = glob.glob(os.path.join(src, '%02d-%s*' % (k + 1, sid)))[0]
    dur = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f], capture_output=True, text=True).stdout)
    sil = silences(f, dur)
    t0 = sil[0][1] if sil and sil[0][0] < 0.05 else 0.0
    t1 = sil[-1][0] if sil and sil[-1][1] > dur - 0.05 else dur
    inner = [s for s in sil if s[0] > t0 + 0.2 and s[1] < t1 - 0.2]
    # Wörter mit Silbengewicht; Grenzen nach Satzzeichen sind mögliche Anker
    words = []; bounds = []  # bounds: (index des Folgeworts, stärke)
    for si, (_, txt) in enumerate(N[sid]):
        toks = txt.split()
        for wi, w in enumerate(toks):
            words.append([si, w, syl(w)])
            last = wi == len(toks) - 1
            if last and si < len(N[sid]) - 1: bounds.append((len(words), 3))
            elif re.search(r'[.!?]$', w): bounds.append((len(words), 2))
            elif re.search(r'[,:;]$', w): bounds.append((len(words), 1))
    cum = [0.0]
    for w in words: cum.append(cum[-1] + w[2])
    # Anker der Reihe nach festlegen, Sprechtempo passt sich an
    anchors = [(0, t0, t0)]  # (wortindex, ende vorher, start nachher)
    pos_t = t0; pos_w = 0; used = -1
    for bi, (wi, strength) in enumerate(bounds):
        rate = (t1 - pos_t) / max(1e-6, (cum[-1] - cum[pos_w]))
        exp = pos_t + (cum[wi] - cum[pos_w]) * rate
        win = {3: 2.2, 2: 1.2, 1: 0.6}[strength]
        cand = [(abs((s + e) / 2 - exp), j, s, e) for j, (s, e) in enumerate(inner) if j > used and abs((s + e) / 2 - exp) < win]
        if strength == 1: cand = [c for c in cand if c[3] - c[2] >= 0.14]
        if cand:
            _, j, s, e = min(cand)
            anchors.append((wi, s, e)); used = j; pos_t = e; pos_w = wi
        elif strength == 3:
            anchors.append((wi, exp, exp)); pos_t = exp; pos_w = wi
    anchors.append((len(words), t1, t1))
    # Wortstarts zwischen den Ankern nach Silben verteilen
    wt = [0.0] * len(words)
    for (a, _, ta), (b, tb, _) in zip(anchors, anchors[1:]):
        span = cum[b] - cum[a]
        for i in range(a, b): wt[i] = ta + (cum[i] - cum[a]) / max(1e-6, span) * (tb - ta)
    segs = []
    for si in range(len(N[sid])):
        idx = [i for i, w in enumerate(words) if w[0] == si]
        a, b = idx[0], idx[-1] + 1
        end = [x for x in anchors if x[0] == b]
        segs.append({'s': round(wt[a], 2), 'e': round(end[0][1] if end else t1, 2), 'w': [round(wt[i], 2) for i in idx]})
    out[sid] = segs
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', f, '-af', 'loudnorm=I=-16:TP=-1.5', '-ac', '1', '-c:a', 'libmp3lame', '-b:a', '48k', '-ar', '24000', 'audio/%s.mp3' % sid], check=True)
    print(sid, '%d Anker auf %d Wörter' % (len(anchors) - 2, len(words)), [s['s'] for s in segs])
json.dump(out, open('narr_timing.json', 'w'))
