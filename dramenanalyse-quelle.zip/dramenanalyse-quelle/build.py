import base64, glob, json, os, shutil
from PIL import Image, ImageDraw, ImageFont
FD='/home/claude/fonts/node_modules/@fontsource'
fonts=[("Bricolage Grotesque","bricolage-grotesque","500","normal"),("Bricolage Grotesque","bricolage-grotesque","700","normal"),("Bricolage Grotesque","bricolage-grotesque","800","normal"),
("Literata","literata","400","normal"),("Literata","literata","600","normal"),("Literata","literata","400","italic"),
("Caveat","caveat","600","normal"),("IBM Plex Mono","ibm-plex-mono","400","normal"),("IBM Plex Mono","ibm-plex-mono","500","normal"),("IBM Plex Mono","ibm-plex-mono","400","italic")]
css=""
for fam,pkg,w,st in fonts:
    p=f"{FD}/{pkg}/files/{pkg}-latin-{w}-{st}.woff2"
    b=base64.b64encode(open(p,'rb').read()).decode()
    css+=f"@font-face{{font-family:'{fam}';font-style:{st};font-weight:{w};font-display:swap;src:url(data:font/woff2;base64,{b}) format('woff2')}}\n"
src=open('app.html',encoding='utf-8').read().replace('/*FONTS*/',css)
import subprocess, re, html as H
a=src.index("/* ================= DATEN ================= */"); b=src.index("/* ================= ZUSTAND")
js=src[a:b]+"\nconsole.log(JSON.stringify({PARTS:PARTS,B:B,ST:ST,SO:SO,CMP:CMP,EX:EX,Q:Q}))"
D=json.loads(subprocess.run(['node','-e',js],capture_output=True,text=True,check=True).stdout)
e=lambda t:H.escape(str(t),quote=False)
st=re.findall(r'<section class="station" id="s-([a-z-]+)" data-look="[a-z]+" data-title="([^"]+)" data-min="(\d+)"(?: data-type="([^"]+)")?',src)
assert len(st)==15, len(st)
def items(pi,a,b):
    p=D['PARTS'][pi]; h=f'<div class="items-head"><h2>{e(p["name"])}</h2><span class="sub">{e(p["sub"])}</span></div><div class="items">'
    for it in p['items'][a:b+1]:
        h+=f'<details class="s-item"><summary>{e(it["t"])}</summary><div class="body"><p>{e(it["d"])}</p><div class="baustein"><b>Satzbaustein</b>{e(it["b"])}</div>'+(f'<p class="hand">{e(it["x"])}</p>' if it["x"] else '')+'</div></details>'
    return h+'</div>'
def deck(cats):
    cs=cats.split(','); h='<p class="sub">Karte antippen zum Aufdecken</p><div class="s-deck">'
    for t,c,src_,d,x in D['B']:
        if c in cs: h+=f'<details class="s-card"><summary><small>{e(c)} · {"Unterlagen" if src_=="u" else "Ergänzung"}</small><b>{e(t)}</b></summary><p>{e(d)}</p>'+(f'<p class="hand">{e(x)}</p>' if x else '')+'</details>'
    return h+'</div>'
def gl():
    return ''.join(f'<div class="glb"><h3>{e(p["name"])}<span class="sub">{e(p["sub"])}</span></h3><div class="glbar"><i style="width:{p["share"]}%"></i></div><ol>'+''.join(f'<li>{e(i["t"])}</li>' for i in p['items'])+'</ol></div>' for p in D['PARTS'])
def tl():
    mn,mx=1450,1820; x=lambda y:(y-mn)/(mx-mn)*100; h=''
    for j,(n,a_,b_,c) in enumerate([("Renaissance",1470,1600,"var(--rule)"),("Barock",1600,1720,"var(--pen)"),("Aufklärung",1720,1800,"var(--mint)")]):
        h+=f'<div class="bar" style="left:{x(a_):.2f}%;width:calc({x(b_)-x(a_):.2f}% - 3px);background:{c};--j:{j}"></div><div class="lab" style="left:{x(a_):.2f}%">{e(n)}</div>'
    return h+''.join(f'<div class="yr" style="left:{x(y):.2f}%">{y}</div>' for y in (1470,1600,1720,1800))
def cmp():
    h='<thead><tr><th></th><th>Antike</th><th>Barock</th><th>Aufklärung</th></tr></thead><tbody>'
    for r in D['CMP']: h+='<tr><th>'+e(r[0])+'</th>'+''.join(f'<td>{e(c)}</td>' for c in r[1:])+'</tr>'
    return h+'</tbody>'
def pool():
    return '<ul class="s-list">'+''.join(f'<li>{e(t)}<details class="s-sol"><summary>Lösung</summary><p><b>{"offene" if k=="o" else "verdeckte"} Handlung.</b> {e(w)}</p></details></li>' for t,k,w in D['SO'])+'</ul>'
def margin():
    return '<div class="s-notes">'+''.join(f'<div><span class="q">{e(n["q"])}</span><p class="hand">{e(n["y"])}</p><p>{e(n["a"])}</p></div>' for n in D['ST'])+'</div>'
def quiz():
    h='<ol class="s-list">'
    for q,opts,c,ex in D['Q']:
        h+=f'<li><div class="q">{e(q)}</div><ol type="A">'+''.join(f'<li>{e(o)}</li>' for o in opts)+f'</ol><details class="s-sol"><summary>Lösung</summary><p><b>{"ABCD"[c]}: {e(opts[c])}</b></p><p>{e(ex)}</p></details></li>'
    return h+'</ol>'
def route():
    return ''.join(f'<li><a href="#s-{i}"><span class="n">{k+2:02d}</span><span>{e(t)}</span><span class="m">{m}′</span></a></li>' for k,(i,t,m,ty) in enumerate(st[1:]))
def pathlist():
    return ''.join(f'<li><a href="#s-{i}"><span class="d" aria-hidden="true"></span><span>{e(t)}'+(f'<span class="u">{ty}</span>' if ty else '')+f'</span><span class="m">{m}′</span></a></li>' for i,t,m,ty in st)
def spick():
    return ''.join(f'<div class="glb"><h3>{e(p["name"])}<span class="sub">{e(p["sub"])}</span></h3><ul style="margin-top:12px">'+''.join(f'<li>{e(i["t"])}</li>' for i in p['items'])+'</ul></div>' for p in D['PARTS'])
def outtext():
    x=D['EX']['antigone']
    p1=f'{x["einstieg"]} In der {x["gattung"]} „{x["titel"]}“ von {x["autor"]} ({x["jahr"]}), die der Epoche {x["epoche"]} zuzuordnen ist, geht es darum, dass {x["thema"]}. {x["kontext"]}'
    p2=f'Die vorliegende Szene ({x["szene"]}) spielt {x["ort"]}; auftreten {x["figuren"]}. {x["inhalt"]} {x["einordnung"]} Vermutlich zeigt die Szene, dass {x["hypo"]}.'
    return f'<p class="sub" style="margin-bottom:10px">Beispiel an Antigone:</p><p>{e(p1)}</p><p>{e(p2)}</p>'
def plan():
    h,t='',0
    for n,f,c in [("Lesen, markieren",.12,"var(--verdeckt)"),("Gliederung, Hypothese",.08,"var(--mint)"),("Einleitung",.08,"var(--offen)"),("Hauptteil",.34,"var(--plum-t)"),("Schluss, Deutung",.11,"var(--offen)"),("Vergleich",.20,"var(--teal-t)"),("Korrektur",.07,"var(--rule)")]:
        mm=max(5,round(135*f/5)*5); h+=f"<tr><td><i style='background:{c}'></i>{n}</td><td>{mm} min</td><td>{t}–{t+mm}</td></tr>"; t+=mm
    return h
def resume(): return '<a class="nextcard" style="margin-top:0" href="#s-plan"><span><small>Los geht’s</small><b>Lernpfad starten</b></span></a>'
def gen(tag):
    k,_,arg=tag.partition(':')
    if k=='items': pi,r=arg.split(':'); a_,b_=map(int,r.split('-')); return items(int(pi),a_,b_)
    if k=='deck': return deck(arg)
    return {'gl':gl,'tl':tl,'cmp':cmp,'pool':pool,'margin':margin,'quiz':quiz,'route':route,'resume':resume,'spick':spick,'outtext':outtext,'pathlist':pathlist,'plan':plan}[k]()
import datetime
src=src.replace('__BUILD__',datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1))).strftime('%d.%m.%Y, %H:%M'))
src=re.sub(r'<!--S:([^>]+?)-->',lambda m:gen(m.group(1)),src)
_N=json.load(open('narration.json',encoding='utf-8'));_T=json.load(open('narr_timing.json'))
_ND={k:{'a':base64.b64encode(open(f'audio/{k}.mp3','rb').read()).decode(),'t':_T[k],'s':_N[k]} for k in _N}
src=src.replace('/*NARRDATA*/null',json.dumps(_ND,ensure_ascii=False).replace('</','<\\/'),1)
assert '<!--S:' not in src
os.makedirs('dist/website',exist_ok=True)
open('dist/dramenanalyse.html','w',encoding='utf-8').write(src.replace('<!--PWA-->',''))
pwa='<link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icon-180.png"><link rel="icon" type="image/png" href="icon-192.png">'
open('dist/website/index.html','w',encoding='utf-8').write(src.replace('<!--PWA-->',pwa))
# Icon: dunkle Bühne, lila Vorhang, Mint-Marker, roter Faden
def icon(S):
    im=Image.new('RGB',(S,S),'#17181d');d=ImageDraw.Draw(im);u=S/180
    for i,x in enumerate(range(0,int(30*u),int(6*u) or 1)):
        d.rectangle([x,0,x+3*u,S],fill='#432470' if i%2==0 else '#2a1549');d.rectangle([S-x-3*u,0,S-x,S],fill='#432470' if i%2==0 else '#2a1549')
    r=8*u
    for cx in range(0,S+int(2*r),int(2*r)):
        d.ellipse([cx-r,-r,cx+r,r],fill='#432470')
    d.rectangle([42*u,70*u,138*u,112*u],fill='#9fe4d0')
    f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',int(40*u))
    d.text((90*u,91*u),"Dr",font=f,fill='#16181b',anchor='mm')
    d.line([(40*u,140*u),(70*u,128*u),(100*u,146*u),(140*u,132*u)],fill='#d4392c',width=max(2,int(5*u)),joint='curve')
    return im
for s in (180,192,512): icon(s).save(f'dist/website/icon-{s}.png')
# Vorschaubild für geteilte Links (WhatsApp, iMessage, Discord)
def og():
    W,Hh=1200,630; im=Image.new('RGB',(W,Hh),'#17181d'); d=ImageDraw.Draw(im)
    for x in range(0,90): a=int(150*(1-x/90)); d.line([(x,0),(x,Hh)],fill=(67+0*a//150,36,112) if False else (int(23+44*(1-x/90)),int(24+12*(1-x/90)),int(29+83*(1-x/90))))
    for x in range(0,90): d.line([(W-1-x,0),(W-1-x,Hh)],fill=(int(23+44*(1-x/90)),int(24+12*(1-x/90)),int(29+83*(1-x/90))))
    B_=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',86); R_=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',34); M_=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',26)
    d.text((140,170),"LERNPFAD · DEUTSCH-KLAUSUR",font=M_,fill='#c9b3ef')
    w=d.textlength("Dramenszene",font=B_); d.rectangle([132,236,148+w,330],fill='#e3d6f3')
    d.text((140,228),"Dramenszene",font=B_,fill='#16181b'); d.text((140,330),"analysieren",font=B_,fill='#f2f0e8')
    d.text((140,470),"Aufbau · Fachbegriffe · Antigone · Epochen · Quiz",font=R_,fill='#b8b9b4')
    d.line([(140,545),(560,545)],fill='#c44634',width=5); d.ellipse([552,537,568,553],fill='#c44634'); d.line([(568,545),(1060,545)],fill='#3a3c42',width=5)
    im.save('dist/website/og.png',optimize=True)
og()

json.dump({"name":"Dramenszene analysieren","short_name":"Dramenanalyse","start_url":"./","scope":"./","display":"standalone","background_color":"#17181d","theme_color":"#17181d","lang":"de",
 "icons":[{"src":"icon-192.png","sizes":"192x192","type":"image/png"},{"src":"icon-512.png","sizes":"512x512","type":"image/png"}]},open('dist/website/manifest.webmanifest','w'),ensure_ascii=False,indent=1)
open('dist/website/sw.js','w').write("""// Immer zuerst die neueste Fassung von GitHub holen (am HTTP-Cache vorbei), offline aus dem Speicher.
const C='dramenanalyse-v4';const A=['./','./index.html','./manifest.webmanifest','./icon-180.png','./icon-192.png','./icon-512.png','./og.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(A.map(u=>new Request(u,{cache:'reload'})))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!==C).map(n=>caches.delete(n)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET'||new URL(r.url).origin!==location.origin)return;
  e.respondWith(fetch(r.url,{cache:'no-cache',credentials:'same-origin'}).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(r,cp))}return res})
    .catch(()=>caches.match(r,{ignoreSearch:true}).then(m=>m||caches.match('./index.html'))))});
""")
shutil.make_archive('dist/dramenanalyse-website','zip','dist/website')
for f in sorted(glob.glob('dist/**',recursive=True)):
    if os.path.isfile(f): print(f, os.path.getsize(f))
