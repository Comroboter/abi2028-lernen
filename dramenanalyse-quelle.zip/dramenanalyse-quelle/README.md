# Quelltext: Lernseite Dramenszenenanalyse (Antigone)

- `fertig/` ist die veröffentlichte Website (index.html ist eigenständig, Audio und Schriften eingebettet).
- `app.html` ist die Vorlage mit allem CSS, HTML und JavaScript. Platzhalter wie `/*FONTS*/`, `<!--S:...-->`, `/*NARRDATA*/null` und `__BUILD__` füllt `build.py`.
- `build.py` erzeugt `dist/`. Es braucht Python 3 mit Pillow, Node.js und die Schriften:
  `npm install @fontsource/bricolage-grotesque @fontsource/literata @fontsource/caveat @fontsource/ibm-plex-mono`
  Danach in `build.py` die Variable `FD` auf den Ordner `node_modules/@fontsource` setzen und die Ausgabepfade bei Bedarf anpassen.
- `narration.json`: Erklärtexte pro Station mit CSS-Selektor des erklärten Elements.
- `audio/` und `narr_timing.json`: ElevenLabs-Aufnahmen (Stimme Livia) und geschätzte Wortzeiten. `import_audio.py <ordner>` erzeugt beides neu aus Dateien `01-start.mp3` bis `15-kurz-vorher.mp3`.
- `narrate.py`: Notlösung mit Piper-Stimme (niedrige Qualität).
- `parts/`: HTML der Stationen Antigone deuten und Szenen vergleichen.
